from SupportCourse import SupportCourse as sc
class RegisterCourse():
	"""docstring for RegisterCourse"""

	registred_employee_details={}
	registred_email_address:str
	registred_course_name:str
	def __init__(self,registred_course_name,registred_email_address):
		#
		self.registred_course_name=registred_course_name
		self.registred_email_address=registred_email_address
		#
		if self.registred_course_name in self.registred_employee_details.keys():
			self.registred_employee_details[self.registred_course_name].append(self.registred_email_address)
		else:
			self.registred_employee_details[self.registred_course_name]=[self.registred_email_address]

	def registred_employees_list_for_the_course(var):
		employee_list=RegisterCourse.registred_employee_details.get(var)
		return employee_list

	def no_of_registred_employees_for_the_course(var):
		if RegisterCourse.registred_employee_details.get(var) is None:
		    no_of_employees=0
		else:     	
		    no_of_employees=len(RegisterCourse.registred_employee_details.get(var))
		return no_of_employees               	    

	def course_registration_id_value(self):
		employee_name=sc.get_name_from_email(self.registred_email_address)
		course_registration_id=f"REG-COURSE-{employee_name}-{self.registred_course_name}"
		return course_registration_id
	def remove_employee_from_list(var):
		list(RegisterCourse.registred_employee_details.items())[0][1].remove(var)





		