import unittest
from RegisterCourse import RegisterCourse as rc
from Course import Course
class TestCourseMethods(unittest.TestCase):

    def test_course_offering_id_value(self):
        obj=Course('JAVA','INS1',12072022,4,5)
        self.assertEqual(obj.course_offering_id_value(),'OFFERING-JAVA-INS1')
    def test_get_course_values(self):
        obj=Course('JAVA','INS1',12072022,4,5)
        self.assertEqual(obj.get_course_values(),{'course_name': 'JAVA', 'instructor': 'INS1', 'course_start_date': 12072022, 'minimum_no_of_employees': 4, 'maxium_no_of_employees': 5})
if __name__ == '__main__':
    unittest.main()
