import unittest
from SupportCourse import SupportCourse as sc
class TestSupportCourseMethods(unittest.TestCase):

    def test_get_name_from_email(self):
        self.assertEqual(sc.get_name_from_email('ANDY@GMAIL.COM'),'ANDY')
    def test_get_list_value(self):
    	self.assertEqual(sc.get_list_value(['A@GMAIL.COM','B@GMAIL.COM'],'A'),'A@GMAIL.COM')
    def test_get_command_value(self):
    	self.assertEqual(sc.get_command_value('OFFERING-PYTHON-JOHN',1),'PYTHON')
    	self.assertEqual(sc.get_command_value('REG-COURSE-WOO-PYTHON',2),'WOO')	    
if __name__ == '__main__':
    unittest.main()
