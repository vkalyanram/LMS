import unittest
from RegisterCourse import RegisterCourse as rc
class TestRegisterCourseMethods(unittest.TestCase):

	def test_course_registration_id_value(self):
		obj=rc("JAVA","A@GMAIL.COM")
		self.assertEqual(obj.course_registration_id_value(),'REG-COURSE-A-JAVA')
	def test_registred_employees_list_for_the_course(self):
		self.assertEqual(rc.registred_employees_list_for_the_course("JAVA"),['A@GMAIL.COM','B@GMAIL.COM'])
		self.assertEqual(rc.registred_employees_list_for_the_course("ROR"),None)
	def test_no_of_registred_employees_for_the_course(self):
		obj=rc("JAVA","B@GMAIL.COM")
		self.assertEqual(rc.no_of_registred_employees_for_the_course("JAVA"),2)	
	def test_remove_employee_from_list(self):
		self.assertEqual(rc.remove_employee_from_list("A@GMAIL.COM"),None)
		self.assertEqual(rc.remove_employee_from_list("B@GMAIL.COM"),None)	
	
if __name__ == '__main__':
	unittest.main()
