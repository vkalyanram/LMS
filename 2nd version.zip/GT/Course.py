class Course():
    """This is a Course class contain Course details """
    course_details={} # Course dictionary contains all the details 
    course_name:str
    instructor:str
    course_start_date:int
    maxium_no_of_employees:int
    minimum_no_of_employees:int
    def __init__(self,course_name,instructor,course_start_date,minimum_no_of_employees,maxium_no_of_employees):
        #Sample input Validation
        assert int(minimum_no_of_employees)>0,f"minimum_no_of_employees {minimum_no_of_employees} is not greater than or equal to 1"
        #
        self.course_name=course_name
        self.instructor=instructor
        self.course_start_date=course_start_date
        self.minimum_no_of_employees=minimum_no_of_employees
        self.maxium_no_of_employees=maxium_no_of_employees
        self.course_details={
        "course_name":self.course_name,
        "instructor":self.instructor,
        "course_start_date":self.course_start_date,
        "minimum_no_of_employees":self.minimum_no_of_employees,
        "maxium_no_of_employees":self.maxium_no_of_employees
         }
    def course_offering_id_value(self):
        self.course_offering_id=f"OFFERING-{self.course_details['course_name']}-{self.course_details['instructor']}"
        return self.course_offering_id
    def get_course_values(self):
        return self.course_details          
    


