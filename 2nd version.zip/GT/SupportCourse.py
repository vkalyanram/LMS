class SupportCourse:
    """docstring for RegisterCourse"""
    def get_name_from_email(email):
        return email.split('@')[0] 
   
    def get_list_value(list_var,var):
        return_var=[x for x in list_var if var in x]
        return return_var[0]
    def get_command_value(command,index):
        return command.split('-')[index] 