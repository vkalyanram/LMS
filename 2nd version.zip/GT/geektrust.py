from sys import argv
from Course import Course as c
from RegisterCourse import RegisterCourse as rc
from CourseManagement import CourseManagement as cm
from SupportCourse import SupportCourse as sc
def main():
		if len(argv) != 2:
				raise Exception("File path not entered")
		input_validation_variable=2 
		input_validation_error="INPUT_DATA_ERROR"
		course_full_error="COURSE_FULL_ERROR"
		course_management_object=cm()
		file_path = argv[1]
		f = open(file_path, 'r')
		Lines = f.readlines()
		for line in Lines:
				query=line.strip().split(' ')
				if len(query)<input_validation_variable:
						print(input_validation_error) 
				else:      
						if query[0]=='ADD-COURSE-OFFERING': 
									try:
											course_object=c(query[1],query[2],query[3],query[4],query[5])
											print(course_object.course_offering_id_value())
											course_details=course_object.get_course_values()
											#print(course_details)
											course_name=course_details.get('course_name')
									except:
											print(input_validation_error) 

						if query[0]=='REGISTER':
									maximum_no_employees=int(course_details.get('maxium_no_of_employees'))
									no_of_employees_already_registred=rc.no_of_registred_employees_for_the_course(course_name)                      
									#print(maximum_no_employees,no_of_employees_already_registred)
									if maximum_no_employees>=no_of_employees_already_registred+1:
											try:	
													registercourse_object=rc(sc.get_command_value(query[2],1),query[1])
													print(registercourse_object.course_registration_id_value()+" ACCEPTED")
													#print(rc.registred_employees_list_for_the_course(course_name))
											except:
													print(input_validation_error)    
									else:
											print(course_full_error) 
						if query[0]=='ALLOT':
									course_management_object.allot_course(query[1],course_details)
						if query[0]=='CANCEL':
									print(course_management_object.cancel_registration(query[1]))
														
if __name__ == "__main__":
		main()

