from RegisterCourse import RegisterCourse as rc
from SupportCourse import SupportCourse as sc
class CourseManagement():
	"""docstring for CourseManagement"""
	__course_allotment_status=False
	
	def allot_course(self,course_offering_id,course_details):

		CourseManagement.__course_allotment_status=True
		course_to_be_alloted=sc.get_command_value(course_offering_id,1)
		no_of_registred_employees_for_the_course=rc.no_of_registred_employees_for_the_course(course_to_be_alloted)
		minimum_no_of_employees=int(course_details.get('minimum_no_of_employees'))
		registred_employees_list_for_the_course=rc.registred_employees_list_for_the_course(course_to_be_alloted)
		registred_employees_list_for_the_course.sort()

		if no_of_registred_employees_for_the_course<minimum_no_of_employees:
				self.allotment_process_for_course_cancellation(course_to_be_alloted,course_offering_id,course_details,registred_employees_list_for_the_course)

		else:        
				self.allotment_process_for_course_confirmation(course_to_be_alloted,course_offering_id,course_details,registred_employees_list_for_the_course)

	def cancel_registration(self,course_registration_id):

		if CourseManagement.__course_allotment_status:
			status=f"{course_registration_id} CANCEL_REJECTED"
			return status

		else:
			self.cancellation_process_for_course_registration(course_registration_id) 
			status=f"{course_registration_id} CANCEL_ACCEPTED"
			return status		

	@staticmethod
	def cancellation_process_for_course_registration(course_registration_id):
				cancel_employee_name=sc.get_command_value(course_registration_id,2)
				cancel_course_name=sc.get_command_value(course_registration_id,3)
				registred_employees_list_for_the_course=rc.registred_employees_list_for_the_course(cancel_course_name)
				cancel_employee_email=sc.get_list_value(registred_employees_list_for_the_course,cancel_employee_name)
				rc.remove_employee_from_list(cancel_employee_email)

	@staticmethod
	def allotment_process_for_course_cancellation(course_to_be_alloted,course_offering_id,course_details,registred_employees_list_for_the_course):
		for employee in registred_employees_list_for_the_course:
					employee_name=sc.get_name_from_email(employee)
					employee_email=employee
					course_start_date=course_details.get('course_start_date')
					instructor_name=sc.get_command_value(course_offering_id,2)
					course_registration_id=f"REG-COURSE-{employee_name}-{course_to_be_alloted}"
					status="COURSE_CANCELED"
					allot=f'{course_registration_id} {employee_email} {course_offering_id} {course_to_be_alloted} {instructor_name} {course_start_date} {status}'
					print(allot)
	@staticmethod
	def allotment_process_for_course_confirmation(course_to_be_alloted,course_offering_id,course_details,registred_employees_list_for_the_course):
		for employee in registred_employees_list_for_the_course:
				employee_name=sc.get_name_from_email(employee)
				employee_email=employee
				course_start_date=course_details.get('course_start_date')
				instructor_name=sc.get_command_value(course_offering_id,2)
				course_registration_id=f"REG-COURSE-{employee_name}-{course_to_be_alloted}"
				status="CONFIRMED"
				allot=f'{course_registration_id} {employee_email} {course_offering_id} {course_to_be_alloted} {instructor_name} {course_start_date} {status}'
				print(allot)		
		
	
		