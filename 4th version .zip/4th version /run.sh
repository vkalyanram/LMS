#!/bin/bash

pip install -r requirements.txt
python3.8  geektrust.py sample_input/input1.txt
python3.8  geektrust.py sample_input/input2.txt
python3.8 -m unittest discover

