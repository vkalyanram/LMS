from dataclasses import dataclass
@dataclass
class Course():
    
    course_name:str
    instructor:str
    course_start_date:int
    minimum_no_of_employees:int
    maxium_no_of_employees:int
    
    def course_offering_id_value(self):
        self.course_offering_id=f"OFFERING-{self.course_name}-{self.instructor}"
        return self.course_offering_id

    def get_course_values(self):
        self.course_details={
        "course_name":self.course_name,
        "instructor":self.instructor,
        "course_start_date":self.course_start_date,
        "minimum_no_of_employees":self.minimum_no_of_employees,
        "maxium_no_of_employees":self.maxium_no_of_employees
        }
        return self.course_details
      